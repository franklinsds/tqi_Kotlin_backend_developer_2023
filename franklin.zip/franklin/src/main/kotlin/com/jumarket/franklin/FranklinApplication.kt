package com.jumarket.franklin

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class FranklinApplication

fun main(args: Array<String>) {
	runApplication<FranklinApplication>(*args)
}
